import Header from './components/Header';
import Hero from './components/Hero';
import Philosophy from './components/Philosophy';
import TheCraft from './components/TheCraft';
import Collections from './components/Collections';
import Mosaic from './components/Mosaic';
import PreFooter from './components/PreFooter';
import Footer from './components/Footer';

export default function App() {
  return (
    <main className="bg-theme-light min-h-screen">
      <Header />
      <Hero />
      <Philosophy />
      <TheCraft />
      <Collections />
      <Mosaic />
      <PreFooter />
      <Footer />
    </main>
  );
}

