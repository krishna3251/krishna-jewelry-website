import { motion } from 'motion/react';

export default function Mosaic() {
  return (
    <section className="py-32 bg-theme-light text-theme-dark overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        <div className="text-center mb-24">
          <motion.h2 
            className="font-serif text-5xl md:text-7xl lg:text-8xl leading-[0.9]"
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 1 }}
          >
            In <br/>
            <em className="italic text-theme-accent">Good</em> <br/>
            Company
          </motion.h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center relative">
          <motion.div 
            className="md:col-span-5 md:col-start-2 aspect-[4/5] rounded-2xl overflow-hidden z-10"
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <img 
              src="https://images.unsplash.com/photo-1599643478524-fb66f70a00ea?q=80&w=2940&auto=format&fit=crop" 
              alt="Model wearing jewelry" 
              className="w-full h-full object-cover"
            />
          </motion.div>

          <div className="md:col-span-4 md:col-start-8 flex flex-col gap-12 z-20 md:-ml-12 mt-12 md:mt-0">
            <motion.div 
              className="aspect-square rounded-2xl overflow-hidden shadow-2xl"
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: 0.2 }}
            >
              <img 
                src="https://images.unsplash.com/photo-1611591437281-460bfbe1220a?q=80&w=2940&auto=format&fit=crop" 
                alt="Jewelry details" 
                className="w-full h-full object-cover"
              />
            </motion.div>

            <motion.div
              className="bg-white/80 backdrop-blur-md p-8 rounded-2xl shadow-xl"
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: 0.4 }}
            >
              <p className="text-lg md:text-xl font-serif mb-4">
                A <em className="italic text-theme-accent">network</em> of creators, curators, and places that <em className="italic text-theme-accent">embody</em> the Krishna spirit.
              </p>
              <p className="text-sm text-theme-dark/60 leading-relaxed">
                From the finest ateliers in Paris to boutiques around the world, Krishna connects those who share a taste for purity, craft, and timeless elegance.
              </p>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
}
