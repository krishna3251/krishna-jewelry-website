import { motion } from 'motion/react';
import { useState, useEffect, useRef } from 'react';
import { X } from 'lucide-react';
import { cn } from '../utils';

const collections = [
  {
    id: 1,
    name: "Aura",
    subtitle: "Diamond Collection",
    image: "https://images.unsplash.com/photo-1605100804763-247f6612148e?q=80&w=2940&auto=format&fit=crop",
    desc: "Brilliant cut diamonds set in 18k white gold. A celebration of light and clarity.",
    details: ["Conflict-free diamonds", "18k White Gold", "Hand-set in Paris"]
  },
  {
    id: 2,
    name: "Lumina",
    subtitle: "Gold Essentials",
    image: "https://images.unsplash.com/photo-1599643477877-530eb83abc8e?q=80&w=2940&auto=format&fit=crop",
    desc: "Sculptural forms in solid yellow gold. Designed for everyday elegance.",
    details: ["100% Recycled Gold", "18k Yellow Gold", "Seamless finish"]
  },
  {
    id: 3,
    name: "Celeste",
    subtitle: "Sapphire Series",
    image: "https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?q=80&w=2940&auto=format&fit=crop",
    desc: "Deep blue sapphires surrounded by a halo of micro-pave diamonds.",
    details: ["Ceylon Sapphires", "Platinum Setting", "Vintage inspired"]
  },
  {
    id: 4,
    name: "Verdant",
    subtitle: "Emerald Collection",
    image: "https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?q=80&w=2940&auto=format&fit=crop",
    desc: "Vibrant emeralds set in rich 18k yellow gold, echoing the lushness of nature.",
    details: ["Zambian Emeralds", "18k Yellow Gold", "Art Deco design"]
  }
];

export default function Collections() {
  const [selectedCol, setSelectedCol] = useState<number | null>(null);
  const modalRef = useRef<HTMLDivElement>(null);
  const closeButtonRef = useRef<HTMLButtonElement>(null);
  const triggerRefs = useRef<(HTMLDivElement | null)[]>([]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && selectedCol !== null) {
        closeModal();
      }
      
      // Focus trapping
      if (e.key === 'Tab' && selectedCol !== null && modalRef.current) {
        const focusableElements = modalRef.current.querySelectorAll(
          'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
        );
        const firstElement = focusableElements[0] as HTMLElement;
        const lastElement = focusableElements[focusableElements.length - 1] as HTMLElement;

        if (e.shiftKey) {
          if (document.activeElement === firstElement) {
            lastElement.focus();
            e.preventDefault();
          }
        } else {
          if (document.activeElement === lastElement) {
            firstElement.focus();
            e.preventDefault();
          }
        }
      }
    };

    if (selectedCol !== null) {
      document.addEventListener('keydown', handleKeyDown);
      // Prevent scrolling on body
      document.body.style.overflow = 'hidden';
      
      // Focus the close button when modal opens
      setTimeout(() => {
        closeButtonRef.current?.focus();
      }, 100);
    } else {
      document.body.style.overflow = 'unset';
    }

    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'unset';
    };
  }, [selectedCol]);

  const openModal = (id: number) => {
    setSelectedCol(id);
  };

  const closeModal = () => {
    const prevSelected = selectedCol;
    setSelectedCol(null);
    
    // Return focus to the trigger element
    if (prevSelected !== null) {
      const index = collections.findIndex(c => c.id === prevSelected);
      if (index !== -1 && triggerRefs.current[index]) {
        triggerRefs.current[index]?.focus();
      }
    }
  };

  return (
    <section id="collections" className="py-32 bg-theme-light text-theme-dark relative">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        <div className="mb-16 max-w-2xl">
          <h2 className="font-serif text-4xl md:text-5xl mb-4">The Collections</h2>
          <p className="text-theme-dark/60 text-lg">Real Gems. Master Crafted. Naturally Different.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {collections.map((col, i) => (
            <motion.div 
              key={col.id}
              ref={(el) => triggerRefs.current[i] = el}
              role="button"
              tabIndex={0}
              aria-haspopup="dialog"
              aria-expanded={selectedCol === col.id}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  openModal(col.id);
                }
              }}
              className={cn(
                "group relative overflow-hidden rounded-xl cursor-pointer focus:outline-none focus:ring-2 focus:ring-theme-accent focus:ring-offset-4 focus:ring-offset-theme-light",
                i === 0 ? "md:col-span-2 aspect-[16/9]" : "aspect-[3/4]"
              )}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.8, delay: i * 0.2 }}
              onClick={() => openModal(col.id)}
            >
              <img 
                src={col.image} 
                alt={col.name} 
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-80" />
              <div className="absolute bottom-0 left-0 p-8 text-white">
                <p className="uppercase tracking-widest text-xs mb-2 text-theme-accent">{col.subtitle}</p>
                <h3 className="font-serif text-3xl">{col.name}</h3>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Modal */}
      {selectedCol && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 md:p-12">
          <motion.div 
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            onClick={closeModal}
            aria-hidden="true"
          />
          <motion.div 
            ref={modalRef}
            role="dialog"
            aria-modal="true"
            aria-labelledby="modal-title"
            aria-describedby="modal-desc"
            className="relative bg-theme-light w-full max-w-5xl h-full max-h-[80vh] rounded-2xl overflow-hidden flex flex-col md:flex-row shadow-2xl"
            initial={{ opacity: 0, y: 50, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
          >
            <button 
              ref={closeButtonRef}
              className="absolute top-6 right-6 z-10 p-2 bg-white/50 hover:bg-white rounded-full backdrop-blur-md transition-colors focus:outline-none focus:ring-2 focus:ring-theme-accent"
              onClick={closeModal}
              aria-label="Close modal"
            >
              <X size={20} />
            </button>
            
            {collections.filter(c => c.id === selectedCol).map(col => (
              <div key={col.id} className="flex flex-col md:flex-row w-full h-full">
                <div className="w-full md:w-1/2 h-64 md:h-full relative">
                  <img src={col.image} alt={col.name} className="w-full h-full object-cover" />
                </div>
                <div className="w-full md:w-1/2 p-8 md:p-16 flex flex-col justify-center overflow-y-auto">
                  <p className="uppercase tracking-widest text-xs mb-4 text-theme-accent">{col.subtitle}</p>
                  <h3 id="modal-title" className="font-serif text-4xl md:text-5xl mb-6">{col.name}</h3>
                  <p id="modal-desc" className="text-theme-dark/70 mb-12 leading-relaxed">{col.desc}</p>
                  
                  <div className="space-y-6">
                    {col.details.map((detail, idx) => (
                      <div key={idx} className="flex flex-col border-b border-theme-dark/10 pb-4">
                        <span className="text-sm font-medium">{detail}</span>
                      </div>
                    ))}
                  </div>

                  <button className="mt-12 bg-theme-dark text-white px-8 py-4 uppercase tracking-widest text-xs hover:bg-theme-accent transition-colors self-start focus:outline-none focus:ring-2 focus:ring-theme-accent focus:ring-offset-2 focus:ring-offset-theme-light">
                    Explore Collection
                  </button>
                </div>
              </div>
            ))}
          </motion.div>
        </div>
      )}
    </section>
  );
}
