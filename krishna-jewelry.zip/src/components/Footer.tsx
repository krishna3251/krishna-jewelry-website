import { motion } from 'motion/react';

export default function Footer() {
  return (
    <footer className="bg-theme-dark text-theme-light pt-32 pb-12 overflow-hidden">
      {/* Marquee */}
      <div className="flex whitespace-nowrap overflow-hidden mb-32">
        <motion.div 
          className="flex gap-16 items-center"
          animate={{ x: [0, -1035] }}
          transition={{ repeat: Infinity, duration: 20, ease: "linear" }}
        >
          {[...Array(4)].map((_, i) => (
            <h2 key={i} className="font-serif text-6xl md:text-8xl lg:text-9xl text-theme-accent whitespace-nowrap">
              Taste the Clarity <span className="text-theme-light mx-8">•</span>
            </h2>
          ))}
        </motion.div>
      </div>

      <div className="max-w-7xl mx-auto px-6 md:px-12">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-16 mb-24">
          <div className="md:col-span-6 flex flex-col items-center md:items-start text-center md:text-left">
            <h2 className="font-serif text-5xl md:text-7xl uppercase tracking-widest mb-8">Krishna</h2>
            <button className="bg-theme-light text-theme-dark px-8 py-4 uppercase tracking-widest text-xs hover:bg-theme-accent hover:text-white transition-colors">
              Find a Boutique
            </button>
          </div>

          <div className="md:col-span-3">
            <h3 className="uppercase tracking-widest text-xs mb-6 text-theme-light/60">Stay in touch</h3>
            <p className="text-sm mb-6 text-theme-light/80">Sign up for new collections, bespoke services and events.</p>
            <form className="flex flex-col gap-4">
              <input 
                type="email" 
                placeholder="Your email" 
                className="bg-transparent border-b border-theme-light/30 pb-2 text-sm focus:outline-none focus:border-theme-accent transition-colors"
              />
              <button type="submit" className="text-left uppercase tracking-widest text-xs hover:text-theme-accent transition-colors">
                Subscribe
              </button>
            </form>
          </div>

          <div className="md:col-span-3">
            <h3 className="uppercase tracking-widest text-xs mb-6 text-theme-light/60">Follow us</h3>
            <ul className="flex flex-col gap-4">
              <li><a href="#" className="text-sm hover:text-theme-accent transition-colors">Instagram</a></li>
              <li><a href="#" className="text-sm hover:text-theme-accent transition-colors">Pinterest</a></li>
              <li><a href="#" className="text-sm hover:text-theme-accent transition-colors">Facebook</a></li>
            </ul>
          </div>
        </div>

        <div className="flex flex-col md:flex-row justify-between items-center pt-8 border-t border-theme-light/10 text-xs text-theme-light/40 gap-4">
          <p>© Copyright KRISHNA 2026 All Rights Reserved.</p>
          <div className="flex gap-8">
            <a href="#" className="hover:text-theme-light transition-colors">Terms and conditions</a>
            <a href="#" className="hover:text-theme-light transition-colors">Privacy Policy</a>
          </div>
          <p>Website by AI Studio</p>
        </div>
      </div>
    </footer>
  );
}
