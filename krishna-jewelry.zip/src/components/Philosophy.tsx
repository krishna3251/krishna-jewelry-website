import { useRef } from 'react';
import { motion, useScroll, useTransform } from 'motion/react';

export default function Philosophy() {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end end"]
  });

  // Chapter 1 animations
  const opacity1 = useTransform(scrollYProgress, [0, 0.3, 0.4, 0.5], [1, 1, 0, 0]);
  const y1 = useTransform(scrollYProgress, [0, 0.3, 0.4, 0.5], [0, 0, -50, -50]);
  const scale1 = useTransform(scrollYProgress, [0, 0.3, 0.4], [1, 1, 0.95]);
  
  // Chapter 2 animations
  const opacity2 = useTransform(scrollYProgress, [0.4, 0.5, 0.8, 1], [0, 1, 1, 0]);
  const y2 = useTransform(scrollYProgress, [0.4, 0.5, 0.8, 1], [50, 0, 0, -50]);
  const scale2 = useTransform(scrollYProgress, [0.4, 0.5, 0.8], [0.95, 1, 1]);

  return (
    <section id="philosophy" ref={containerRef} className="relative h-[300vh] bg-theme-light text-theme-dark">
      <div className="sticky top-0 h-screen w-full overflow-hidden flex items-center justify-center">
        
        {/* Chapter 1 */}
        <motion.div 
          className="absolute inset-0 flex flex-col items-center justify-center px-6 max-w-5xl mx-auto text-center"
          style={{ opacity: opacity1, y: y1, scale: scale1 }}
        >
          <h2 className="font-serif text-4xl md:text-6xl lg:text-7xl mb-12 leading-tight">
            We go back to <em className="italic text-theme-accent">basics</em>, <br/>
            only <em className="italic text-theme-accent">real</em> elements.
          </h2>
          
          <div className="flex flex-col md:flex-row items-center justify-center gap-8 md:gap-16 w-full">
            <div className="w-64 h-80 overflow-hidden rounded-t-full">
              <img 
                src="https://images.unsplash.com/photo-1584302179602-e4c3d3fd629d?q=80&w=2940&auto=format&fit=crop" 
                alt="Raw gold" 
                className="w-full h-full object-cover"
              />
            </div>
            <div className="max-w-sm text-left">
              <h3 className="uppercase tracking-widest text-xs font-semibold mb-4 text-theme-accent">No compromise. No shortcuts.</h3>
              <p className="text-sm md:text-base leading-relaxed text-theme-dark/80">
                In a world of mass production, we choose restraint. Fewer, better elements handled with care. It’s not about adding more, it’s about revealing what is already perfect.
              </p>
            </div>
          </div>
        </motion.div>

        {/* Chapter 2 */}
        <motion.div 
          className="absolute inset-0 flex flex-col items-center justify-center px-6 max-w-5xl mx-auto text-center"
          style={{ opacity: opacity2, y: y2, scale: scale2 }}
        >
          <h2 className="font-serif text-4xl md:text-6xl lg:text-7xl mb-12 leading-tight">
            Gems born from a <em className="italic text-theme-accent">landscape</em> <br/>
            carved over <em className="italic text-theme-accent">millennia</em>.
          </h2>
          
          <div className="flex flex-col md:flex-row-reverse items-center justify-center gap-8 md:gap-16 w-full">
            <div className="w-64 h-80 overflow-hidden rounded-b-full">
              <img 
                src="https://images.unsplash.com/photo-1573408301145-b98c4fd0113f?q=80&w=2942&auto=format&fit=crop" 
                alt="Diamond close up" 
                className="w-full h-full object-cover"
              />
            </div>
            <div className="max-w-sm text-left md:text-right">
              <h3 className="uppercase tracking-widest text-xs font-semibold mb-4 text-theme-accent">Our foundation. Our proof.</h3>
              <p className="text-sm md:text-base leading-relaxed text-theme-dark/80">
                Our journey begins deep beneath the earth's surface. A natural process of pressure and time, untouched by human hands until the moment of discovery.
              </p>
            </div>
          </div>
        </motion.div>

      </div>
    </section>
  );
}
