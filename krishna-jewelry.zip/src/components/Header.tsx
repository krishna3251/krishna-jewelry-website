import { useState, useEffect } from 'react';
import { motion, useScroll, useMotionValueEvent } from 'motion/react';
import { Menu, X } from 'lucide-react';
import { cn } from '../utils';

export default function Header() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { scrollY } = useScroll();

  useMotionValueEvent(scrollY, "change", (latest) => {
    if (latest > 50) {
      setIsScrolled(true);
    } else {
      setIsScrolled(false);
    }
  });

  const navLinks = [
    { name: 'Philosophy', href: '#philosophy' },
    { name: 'The Craft', href: '#craft' },
    { name: 'Collections', href: '#collections' },
    { name: 'Boutiques', href: '#boutiques' },
  ];

  return (
    <>
      <motion.header
        className={cn(
          'fixed top-0 left-0 right-0 z-50 transition-colors duration-500',
          isScrolled || isMenuOpen ? 'bg-theme-light text-theme-dark shadow-sm' : 'bg-transparent text-white'
        )}
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
      >
        <div className="max-w-7xl mx-auto px-6 md:px-12 h-24 flex items-center justify-between">
          <div className="hidden md:flex items-center gap-8 w-1/3">
            {navLinks.slice(0, 2).map((link) => (
              <a key={link.name} href={link.href} className="text-sm uppercase tracking-widest hover:opacity-70 transition-opacity">
                {link.name}
              </a>
            ))}
          </div>

          <div className="w-1/3 flex justify-center">
            <a href="#" className="font-serif text-4xl md:text-5xl tracking-widest uppercase">
              Krishna
            </a>
          </div>

          <div className="hidden md:flex items-center justify-end gap-8 w-1/3">
            {navLinks.slice(2, 4).map((link) => (
              <a key={link.name} href={link.href} className="text-sm uppercase tracking-widest hover:opacity-70 transition-opacity">
                {link.name}
              </a>
            ))}
          </div>

          <div className="md:hidden flex items-center justify-end w-1/3">
            <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="p-2">
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </motion.header>

      {/* Mobile Menu */}
      <motion.div
        className={cn(
          'fixed inset-0 z-40 bg-theme-light text-theme-dark flex flex-col items-center justify-center',
          isMenuOpen ? 'pointer-events-auto' : 'pointer-events-none'
        )}
        initial={{ opacity: 0 }}
        animate={{ opacity: isMenuOpen ? 1 : 0 }}
        transition={{ duration: 0.5 }}
      >
        <nav className="flex flex-col items-center gap-8">
          {navLinks.map((link) => (
            <a
              key={link.name}
              href={link.href}
              className="font-serif text-3xl uppercase tracking-widest"
              onClick={() => setIsMenuOpen(false)}
            >
              {link.name}
            </a>
          ))}
        </nav>
      </motion.div>
    </>
  );
}
