import { useRef } from 'react';
import { motion, useScroll, useTransform } from 'motion/react';

export default function TheCraft() {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start end", "end start"]
  });

  const y = useTransform(scrollYProgress, [0, 1], ["-20%", "20%"]);

  return (
    <section id="craft" ref={containerRef} className="relative min-h-screen bg-theme-dark text-theme-light overflow-hidden py-32">
      {/* Background Parallax Image */}
      <div className="absolute inset-0 z-0 opacity-40">
        <motion.div className="w-full h-[140%]" style={{ y }}>
          <img 
            src="https://images.unsplash.com/photo-1589674781759-c21c37956a44?q=80&w=2940&auto=format&fit=crop" 
            alt="Jewelry making process" 
            className="w-full h-full object-cover sepia-[.3] hue-rotate-15"
          />
        </motion.div>
        <div className="absolute inset-0 bg-gradient-to-b from-theme-dark via-transparent to-theme-dark" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-6 md:px-12">
        <div className="max-w-2xl mb-24">
          <h2 className="font-serif text-4xl md:text-6xl lg:text-7xl leading-tight">
            The craft is our <br/>
            <em className="italic text-theme-accent">tribute</em> to the source.
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 md:gap-8">
          {[
            {
              label: "The Design",
              title: "Vision",
              desc: "Inspired by ancient motifs and modern minimalism, our designs bridge the gap between eras."
            },
            {
              label: "The Materials",
              title: "Purity",
              desc: "We source only conflict-free diamonds and 18k recycled gold, ensuring every piece respects the earth."
            },
            {
              label: "The Process",
              title: "Precision",
              desc: "Every facet is cut by master artisans, catching light like a glacier at dawn. A tactile landscape of brilliance."
            },
            {
              label: "The Result",
              title: "Eternity",
              desc: "A piece that transcends time. Not just jewelry, but an heirloom crafted to be passed down through generations."
            }
          ].map((item, i) => (
            <motion.div 
              key={i}
              className="flex flex-col gap-4"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.8, delay: i * 0.1 }}
            >
              <p className="uppercase tracking-widest text-xs text-theme-accent">{item.label}</p>
              <h3 className="font-serif text-2xl md:text-3xl">{item.title}</h3>
              <p className="text-sm text-theme-light/70 leading-relaxed">{item.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
