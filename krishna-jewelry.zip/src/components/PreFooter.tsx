import { motion } from 'motion/react';

export default function PreFooter() {
  return (
    <section className="py-32 bg-theme-light text-theme-dark text-center px-6 relative overflow-hidden">
      <div className="max-w-4xl mx-auto flex flex-col items-center gap-12 relative z-10">
        <motion.h2 
          className="font-serif text-5xl md:text-7xl lg:text-8xl leading-tight"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          Leave <br />
          <span className="relative inline-block">
            <em className="italic text-theme-accent relative z-10">no</em>
            <motion.span 
              className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-24 h-24 md:w-32 md:h-32 rounded-full overflow-hidden z-0 opacity-80"
              initial={{ scale: 0 }}
              whileInView={{ scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: 0.4 }}
            >
              <img src="https://images.unsplash.com/photo-1599643477877-530eb83abc8e?q=80&w=2940&auto=format&fit=crop" alt="Nature" className="w-full h-full object-cover" />
            </motion.span>
          </span> <br />
          trace
        </motion.h2>
        
        <motion.p 
          className="max-w-md text-sm md:text-base text-theme-dark/70 leading-relaxed mt-8"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          Our commitment extends beyond purity, it’s a matter of responsibility. We use recycled gold, ethically sourced diamonds, and design processes that respect the earth that inspires us.
        </motion.p>
      </div>
    </section>
  );
}
